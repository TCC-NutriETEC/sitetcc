<?php
//rotas da aplicação
//a variável $uri já contém os dados da rota solicitada

switch ($uri) {
    
    case '/':

        require './app/views/index.html';
        break;

    case '/receitas':
        require './app/views/receitas.html';
        break;

    case '/dicas':
        require './app/views/dicas.html';
        break;
     
    case '/nutricionistas':
        require './app/views/nutricionistas.html';
        break;        

    case '/eventos':
        require './app/views/eventos.html';
        break;

    case '/faq':
        require './app/views/faq.html';
        break;
}
